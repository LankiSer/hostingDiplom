const express = require('express');
const path = require('path');
const os = require('os');

const app = express();
const PORT = process.env.PORT || 3000;
const startTime = Date.now();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/info', (req, res) => {
  res.json({
    app: process.env.APP_NAME || 'hello-app',
    hostname: os.hostname(),
    platform: os.platform(),
    uptime: Math.floor((Date.now() - startTime) / 1000),
    memory: {
      used: Math.round(process.memoryUsage().rss / 1024 / 1024),
      unit: 'MB'
    },
    node: process.version,
    env: process.env.NODE_ENV || 'production',
    time: new Date().toISOString()
  });
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', uptime: Math.floor((Date.now() - startTime) / 1000) });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`hello-app running on port ${PORT}`);
});
