# hello-app

Demo Node.js application for testing [gcloude](http://localhost) hosting platform.

## What it does

- Serves a status page at `/`
- Returns server info at `/api/info` (hostname, uptime, memory, Node version)
- Health check at `/api/health`

## Local run

```bash
npm install
npm start
# open http://localhost:3000
```

## Deploy on gcloude

1. Push this repo to GitHub
2. Open [gcloude control](http://localhost) → Projects → your project
3. Click **Новое приложение**, paste the git URL, select runtime **Node.js**
4. Click **Задеплоить**
5. App will be live at `http://hello-app.apps.localhost`

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3000` | HTTP port |
| `APP_NAME` | `hello-app` | Display name |
| `NODE_ENV` | `production` | Environment |
